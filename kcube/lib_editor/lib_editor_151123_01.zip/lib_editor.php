<?
/*
editor_board_idx		'-- 게시글 key
editor_ifm_name		'-- iframe 이름
editor_form_name		'-- form 이름
editor_contents			'-- 작성된 본문
editor_ele_name		'-- editor element name
editor_height				'-- editor height

editor_file_kind			'-- 업로드 파일 구분 (에디터가 여러개일경우 구분자로 사용)
editor_upload_key		'-- 업로드 폴더 key
editor_img_rs			'-- 업로드 이미지 레코드셋
editor_file_rs				'-- 업로드 파일 레코드셋


arr_tx_attach_image , arr_tx_attach_file
*/

$editor_board_idx = $_GET["editor_board_idx"];
$editor_ifm_name = $_GET["editor_ifm_name"];
$editor_form_name = $_GET["editor_form_name"];
$editor_ele_name = $_GET["editor_ele_name"];
$editor_height = $_GET["editor_height"];

$editor_file_kind = $_GET["editor_file_kind"];
$editor_upload_key = $_GET["editor_upload_key"];
?>