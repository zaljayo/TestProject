<script type="text/javascript">
    var xssDomain = window.location.search.substring(1);
    if (xssDomain) {
        document.domain = xssDomain;
    }
    
    try {
        parent.__tx_wysiwyg_iframe_load_complete();
    } catch (e) {
    }
</script>