<?
include $_SERVER["DOCUMENT_ROOT"]."/lib/web_lib.php";
include $server_root_path."/lib/admin_lib.php";
include $server_root_path."/lib/page_lib.php";
include $server_root_path."/lib_editor/lib_editor.php";


$editor_upload_key = RqStr("editor_upload_key", "");

$file_kind = RqStr("file_kind", "");


get_updir( $editor_upload_key );
$tmp_file = file_upload($GLB_UP_FILE_ROOTDIR, $GLB_UP_FILE_URL, $_FILES['file'], "", "");
$file_name = $tmp_file["name"];
$file_size = $tmp_file["size"];
$file_ext = $tmp_file["ext"];
$file_url = $tmp_file["url"];

if($file_kind == "file"){
?>
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		var _mockdata = {
			'attachurl': '<?= $file_url ?><?= $file_name ?>',
			'filemime': 'image/<?= $file_ext ?>',
			'filename': '<?= $file_name ?>',
			'filesize': <?= $file_size ?>
		};
		parent.done(_mockdata);
	//-->
	</SCRIPT>
<?
}else if($file_kind == "image"){
?>
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		var _mockdata = {
			'imageurl': '<?= $file_url ?><?= $file_name ?>',
			'filename': '<?= $file_name ?>',
			'filesize': <?= $file_size ?>,
			'imagealign': 'C',
			'originalurl': '<?= $file_url ?><?= $file_name ?>',
			'thumburl': '<?= $file_url ?><?= $file_name ?>'
		};
		parent.done(_mockdata);
	//-->
	</SCRIPT>
<?
}
?>